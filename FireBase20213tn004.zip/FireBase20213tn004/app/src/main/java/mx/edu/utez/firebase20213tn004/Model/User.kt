package mx.edu.utez.firebase20213tn004.Model

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class User(val username: String? = null,
                val email:String? = null)