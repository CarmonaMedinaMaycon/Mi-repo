package mx.edu.utez.firebase20213tn004

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import mx.edu.utez.firebase20213tn004.Model.User

class MainActivity : AppCompatActivity() {
    lateinit var database: DatabaseReference
    lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        database = Firebase.database.reference


//insercion
        val user = User("maycon", "mayconcarmona507@gmail.com")
        database.child("users").child("1").setValue(user)
//actualizacion
        var user2 = mapOf(
            "username" to "PALAFOX"
        )
        database.child("users").child("1").updateChildren(user2)
        //eliminacion
       // database.child("users").child("1").removeValue()

///useeee to authenticator
        auth= FirebaseAuth.getInstance()
        auth.signInWithEmailAndPassword("mayconcarmona507@gmail.com", "maycon883062")
            .addOnCompleteListener { task ->
                if (task.isSuccessful){
                    Toast.makeText(this@MainActivity, "Bienvenido", Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this@MainActivity, "error", Toast.LENGTH_SHORT).show()
                }
            }
    }
}