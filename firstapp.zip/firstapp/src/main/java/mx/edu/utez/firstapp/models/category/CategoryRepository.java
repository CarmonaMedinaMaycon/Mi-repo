package mx.edu.utez.firstapp.models.category;

public interface CategoryRepository {
}
