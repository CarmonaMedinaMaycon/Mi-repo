package mx.edu.utez.firstapp.models.subcategory;


public interface SubCategoryRepository {

}
