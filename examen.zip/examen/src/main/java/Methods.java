
import Client.BeanCurp;
import Client.DaoCurp;

import java.util.List;
import java.util.Random;


public class Methods {
    Random random = new Random();

    DaoCurp dao = new DaoCurp();
    BeanCurp bean = new BeanCurp();

    String nm, apm, sapm,s, fn, l;

    public String curp(String nombre, String primerApellido, String segundoApellido, String sexo, String lugarNacimiento, String fechaNacimiento) {
        String curp = "";

        String.valueOf(nombre.charAt(0));
        String.valueOf(primerApellido.charAt(0));
        String.valueOf(segundoApellido.charAt(0));
        s = sexo;
        l = lugarNacimiento;
        //como saber cual es la segunda consonante de una cadena

        char[] consonantes = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};

        int cont2 = 0;
        for(int i=0; i <= nombre.length()-1;i++){
            for(int o = 0; o < consonantes.length; o++){
                if(cont2 < 2){
                    if(nombre.charAt(i) == consonantes[o]){
                        nm = String.valueOf(nombre.charAt(i));
                        cont2 ++;
                    }
                }
            }
        }
         cont2 = 0;
        for(int i=0; i <= primerApellido.length()-1;i++){
            for(int o = 0; o < consonantes.length; o++){
                if(cont2 < 2){
                    if(primerApellido.charAt(i) == consonantes[o]){
                        apm = String.valueOf(primerApellido.charAt(i));
                        cont2 ++;
                    }
                }
            }
        }
         cont2 = 0;
        for(int i=0; i <= segundoApellido.length()-1;i++){
            for(int o = 0; o < consonantes.length; o++){
                if(cont2 < 2){
                    if(segundoApellido.charAt(i) == consonantes[o]){
                        sapm = String.valueOf(segundoApellido.charAt(i));
                        cont2 ++;
                    }
                }
            }
        }






        //
        fn = fechaNacimiento.charAt(2) + "" + fechaNacimiento.charAt(3) + "" + fechaNacimiento.charAt(5) + "" + fechaNacimiento.charAt(6) + "" + fechaNacimiento.charAt(8) + "" + fechaNacimiento.charAt(9) + "";

        char randomizedCharacter = (char) (random.nextInt(26) + 'a');
        int randomInt = random.nextInt(10);


        curp = String.valueOf(primerApellido.charAt(0))+ String.valueOf(primerApellido.charAt(1)) +String.valueOf(segundoApellido.charAt(0)) + String.valueOf(nombre.charAt(0)) + fn + s + l + apm + sapm +  nm +  randomizedCharacter + randomInt;

        return curp;
    }

    public String showThings (String curp){
        dao.showThings(curp);
        String response="";

        System.out.println(bean.getTodo());
        response= bean.getTodo();
        return response;
    }


    public String show ( ){
        List<BeanCurp> historial = dao.show();
        String response="";
        for (int i = 0; i < historial.size(); i++){
            response += " id "+historial.get(i).getId()  +
                    " nombre " + historial.get(i).getPrimerNombre() +
                    " apellido " + historial.get(i).getPrimerApellido() +
                    " apellido " + historial.get(i).getSegundoApellido() +
                    " sexo " + historial.get(i).getSexo() +
                    " lugar nacimiento " + historial.get(i).getLugarNacimiento() +
                    " fecha nacimiento " +historial.get(i).getFechaNacimiento() +
                    " curp " +historial.get(i).getCurp() + "\n";

        }
        return response;
    }

}