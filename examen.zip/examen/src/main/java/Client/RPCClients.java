package Client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Scanner;

public class RPCClients {
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) throws MalformedURLException, XmlRpcException {


        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);

        String nombre, primerApellido, segundoApellido, lugarNacimiento = null;
        String sexo = "", curp="";
        String fechaNacimiento;
        int menu;
        DaoCurp dao = new DaoCurp();
        BeanCurp bean = new BeanCurp();

        do {


            System.out.println("que deseas hacer?");
            System.out.println("1; consultar curp");
            System.out.println("2; consultar datos mediante curp");
            System.out.println("3; consultar todos los datos");
            System.out.println("4; salir");
            menu = leer.nextInt();
            switch (menu) {
                case 1:
                    System.out.println("escribe tu nombre");
                    nombre = leer.next();
                    bean.setPrimerNombre(nombre);
                    System.out.println("escribe tu primer apellido");
                    primerApellido = leer.next();
                    bean.setPrimerApellido(primerApellido);
                    System.out.println("escribe tu segundo apellido");
                    segundoApellido = leer.next();
                    bean.setSegundoApellido(segundoApellido);
                    System.out.println("escribe tu sexo 1:HOMBRE 2:MUJER");
                    menu = leer.nextInt();
                    if (menu == 1) {
                        sexo = "H";
                        bean.setSexo(sexo);
                    } else if (menu == 2) {
                        sexo = "M";
                        bean.setSexo(sexo);
                    } else {
                        System.out.println("ese no es un sexo");
                    }
                    menu=0;

                    do {
                        System.out.println("escribe el lugar donde naciste" +
                                " 1:Aguascalientes \n" +
                                " 2:Baja California \n" +
                                " 3:Baja California Sur \n" +
                                " 4:Campeche \n" +
                                " 5:Coahuila \n" +
                                " 6:Colima \n" +
                                " 7:Chiapas \n" +
                                " 8:Chihuahua \n" +
                                " 9:Distrito Federal \n" +
                                " 10:Durango \n" +
                                " 11:Guanajuato \n" +
                                " 12:Guerrero \n" +
                                " 13:Hidalgo \n" +
                                " 14:Jalisco \n" +
                                " 15:México \n" +
                                " 16:Michoacán \n" +
                                " 17:Morelos \n" +
                                " 18:Nayarit \n" +
                                " 19:Nuevo León \n" +
                                " 20:Oaxaca \n" +
                                " 21:Puebla \n" +
                                " 22:Querétaro \n" +
                                " 23:Quintana Roo\n" +
                                " 24:San Luis Potosí\n" +
                                " 25:Sinaloa\n" +
                                " 26:Sonora\n" +
                                " 27:Tabasco\n" +
                                " 28:Tamaulipas\n" +
                                " 29:Tlaxcala\n" +
                                " 30:Veracruz\n" +
                                " 31:Yucatán\n" +
                                " 32:Zacatecas \n");
                        menu = leer.nextInt();

                        switch (menu) {
                            case 1:
                                lugarNacimiento = "AS";
                                break;
                            case 2:
                                lugarNacimiento = "BC";
                                break;
                            case 3:
                                lugarNacimiento = "BS";
                                break;
                            case 4:
                                lugarNacimiento = "CC";
                                break;
                            case 5:
                                lugarNacimiento = "CL";
                                break;
                            case 6:
                                lugarNacimiento = "CM";
                                break;
                            case 7:
                                lugarNacimiento = "CS";
                                break;
                            case 8:
                                lugarNacimiento = "CH";
                                break;
                            case 9:
                                lugarNacimiento = "DF";
                                break;
                            case 10:
                                lugarNacimiento = "DG";
                                break;
                            case 11:
                                lugarNacimiento = "GT";
                                break;
                            case 12:
                                lugarNacimiento = "GR";
                                break;
                            case 13:
                                lugarNacimiento = "HG";
                                break;
                            case 14:
                                lugarNacimiento = "JC";
                                break;
                            case 15:
                                lugarNacimiento = "MC";
                                break;
                            case 16:
                                lugarNacimiento = "MN";
                                break;
                            case 17:
                                lugarNacimiento = "MS";
                                break;
                            case 18:
                                lugarNacimiento = "NT";
                                break;
                            case 19:
                                lugarNacimiento = "NL";
                                break;
                            case 20:
                                lugarNacimiento = "OC";
                                break;
                            case 21:
                                lugarNacimiento = "PL";
                                break;
                            case 22:
                                lugarNacimiento = "QT";
                                break;
                            case 23:
                                lugarNacimiento = "QR";
                                break;
                            case 24:
                                lugarNacimiento = "SP";
                                break;
                            case 25:
                                lugarNacimiento = "SL";
                                break;
                            case 26:
                                lugarNacimiento = "SR";
                                break;
                            case 27:
                                lugarNacimiento = "TC";
                                break;
                            case 28:
                                lugarNacimiento = "TS";
                                break;
                            case 29:
                                lugarNacimiento = "TL";
                                break;
                            case 30:
                                lugarNacimiento = "VZ";
                                break;
                            case 31:
                                lugarNacimiento = "YN";
                                break;
                            case 32:
                                lugarNacimiento = "ZS";
                                break;
                            default:
                                System.out.println("estado invalido");
                        }
                        bean.setLugarNacimiento(lugarNacimiento);
                    } while (!(menu >= 1 && menu <= 32)); //buscar un rango

                    System.out.println("escribe tu fecha de nacimiento año/mes/dia 2012/12/17");
                    fechaNacimiento = leer.next();
                    bean.setFechaNacimiento(fechaNacimiento);

                    Object[] data = {nombre, primerApellido, segundoApellido, sexo, lugarNacimiento, fechaNacimiento};
                    String response = (String) client.execute("Methods.curp", data);
                    System.out.println("Result ->" + response);
                    bean.setCurp(response);

                    dao.saveCurp(bean);

                    break;
                case 2:
                    System.out.println("escribe tu curp");
                    curp = leer.next();
                    bean.setCurp(curp);
                    Object[] data2 = {curp};
                    String response2 = (String) client.execute("Methods.showThings", data2);
                    System.out.println("Result ->" + response2);

                    break;
                case 3:
                    System.out.println("consultar historial");
                    Object[] data3 = {};
                    String response3 = (String) client.execute("Methods.show", data3);
                    System.out.println("Result ->" + response3);
                    break;

                case 4:
                    System.out.println("saliendo..");
                    break;
                default:
                    System.out.println("elije una respuesta correcta");
                    break;
            }
        }while (menu !=4);
    }

}
