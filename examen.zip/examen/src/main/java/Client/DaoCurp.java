package Client;

import utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoCurp {


    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;

    private final String SHOW = "SELECT * FROM curp;";
    private final String showw = "INSERT INTO  curp (`nombre`,`primerApellido`,`segundoApellido`, `sexo`, `estadoNacimiento`, `fechaNacimiento`,`crup`) VALUES (?,?,?,?,?,?,?);";

    private final String SHOWDATOS = "SELECT * FROM curp where crup = ?";

    public boolean saveCurp(BeanCurp curpi){
        try{
            conn = new MySQLConnection().getConnection();
            pstm = conn.prepareStatement(showw);
            pstm.setString(1, curpi.getPrimerNombre());
            pstm.setString(2, curpi.getPrimerApellido());
            pstm.setString(3, curpi.getSegundoApellido());
            pstm.setString(4, curpi.getSexo());
            pstm.setString(5, curpi.getLugarNacimiento());
            pstm.setString(6, curpi.getFechaNacimiento());
            pstm.setString(7, curpi.getCurp());

            return pstm.executeUpdate() == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCurp.class.getName()).log(Level.SEVERE, "Error saveCurps", e);
        }finally {
            closeConnections(); //si no cierro la coneccion puede explotar
        }
        return false;
    }



    public List<BeanCurp> show (){
        java.util.List<BeanCurp> CurpList = new LinkedList<>();
        BeanCurp curpi = new BeanCurp();

        try {
            conn = new MySQLConnection().getConnection();
            String query = SHOW;
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()){
                curpi = new BeanCurp();
                curpi.setId(rs.getLong("id"));
                curpi.setPrimerNombre(rs.getString("nombre"));
                curpi.setPrimerApellido(rs.getString("primerApellido"));
                curpi.setSegundoApellido(rs.getString("segundoApellido"));
                curpi.setLugarNacimiento(rs.getString("estadoNacimiento"));
                curpi.setFechaNacimiento(rs.getString("fechaNacimiento"));
                curpi.setCurp(rs.getString("crup"));

                CurpList.add(curpi);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoCurp.class.getName()).log(Level.SEVERE, "Error en showCurps -> ", e);
        }finally {
            closeConnections();
        }

        return CurpList;
    }
    public BeanCurp showThings (String curp){
        BeanCurp curpi = null;
        
        try {
            conn = new MySQLConnection().getConnection();
            String query = SHOWDATOS;
            pstm = conn.prepareStatement(query);
            pstm.setString(1, curp);
            rs = pstm.executeQuery();
            while (rs.next()){
                 curpi = new BeanCurp();
                curpi.setId(rs.getLong("id"));
                curpi.setPrimerNombre(rs.getString("nombre"));
                curpi.setPrimerApellido(rs.getString("primerApellido"));
                curpi.setSegundoApellido(rs.getString("segundoApellido"));
                curpi.setLugarNacimiento(rs.getString("estadoNacimiento"));
                curpi.setFechaNacimiento(rs.getString("fechaNacimiento"));

                curpi.setTodo(" Nombre:"+curpi.getPrimerNombre()+"\n"+" ApellidoP:"+curpi.getPrimerApellido()+"\n"+" ApellidoM:"+curpi.getSegundoApellido()+"\n"+" Sexo:"+curpi.getSexo()+" Estado Nacimiento: "+curpi.getLugarNacimiento()+"\n"+" Fecha Nacimiento:"+ curpi.getFechaNacimiento());
                System.out.println(" Nombre:"+curpi.getPrimerNombre()+"\n"+" ApellidoP:"+curpi.getPrimerApellido()+"\n"+" ApellidoM:"+curpi.getSegundoApellido()+"\n"+" Sexo:"+curpi.getSexo()+"\n"+" Estado Nacimiento: "+curpi.getLugarNacimiento()+"\n"+" Fecha Nacimiento:"+ curpi.getFechaNacimiento());

            }
        }catch (SQLException e){
            Logger.getLogger(DaoCurp.class.getName()).log(Level.SEVERE, "Error en showDatos -> ", e);
        }finally {
            closeConnections();
        }

        return curpi;
    }


    public void closeConnections(){
        try {
            if (conn!=null){
                conn.close();
            }
            if (pstm!=null){
                pstm.close();
            }
            if (rs!=null){
                rs.close();
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }




}
