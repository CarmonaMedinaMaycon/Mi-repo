create database mike;
use mike;

create table operations (
id bigint primary key auto_increment,
`type` varchar (15) not null,
firs_Number double  not null,
second_Number double not null,
result double not null,
created_at datetime not null default now()
)
