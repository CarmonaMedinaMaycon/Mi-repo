<?php
header("Content-Type", "application/json");
$method = $_SERVER["REQUEST_METHOD"];

switch ($method) {
    case 'GET':

        try { //conexion
            $conexion = new PDO("mysql:host=localhost;dbname=kof", "root", "");
        } catch (PDOException $e) {
            echo $e->getMessage();
        }

        switch ($_GET['accion']) {
            case "personaje":

                if (isset($_GET['id'])) {


                    $pstm = $conexion->prepare('SELECT personaje.id,personaje.name,lastname,birthday,utiliza_magia,estatura ,peso ,equipo,magia.name as MAGIA , tipo_lucha.name AS lucha FROM kof.personaje inner join magia on magia_id=magia.id inner join tipo_lucha on  tipo_lucha_id = tipo_lucha.id where personaje.id = :num ;');
                    $pstm->bindParam(":num", $_GET['id']);
                    $pstm->execute();
                    $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
                    if ($rs != null) {
                        echo json_encode($rs, JSON_PRETTY_PRINT); // print
                    } else {
                        echo "no se encontrp";
                    }
                } else {
                    $pstm = $conexion->prepare('SELECT personaje.id,personaje.name,lastname,birthday,utiliza_magia,estatura ,peso ,equipo,magia.name as MAGIA , tipo_lucha.name AS lucha FROM kof.personaje inner join magia on magia_id=magia.id inner join tipo_lucha on  tipo_lucha_id = tipo_lucha.id ;');
                    $pstm->execute();
                    $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode($rs, JSON_PRETTY_PRINT);
                }

                break;
            case "magia":

                $pstm = $conexion->prepare('SELECT * FROM kof.magia;');
                $pstm->execute();
                $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($rs, JSON_PRETTY_PRINT);

                break;
            case "tipo_lucha":

                $pstm = $conexion->prepare('SELECT * FROM kof.tipo_lucha;');
                $pstm->execute();
                $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode($rs, JSON_PRETTY_PRINT);

                break;
            default:
                echo "Dno se encontro";
                break;
        }
        break;

    case 'POST':
        if ($_GET['accion'] == 'personaje') {
            $jsonData = json_decode(file_get_contents("php://input"));
            try {
                $conn = new PDO("mysql:host=localhost;dbname=kof", "root", "");
            } catch (PDOException $e) {
                echo $e->getMessage();
            }

            if (!nombres($conn, $jsonData)) {
                $query = $conn->prepare('INSERT INTO `kof`.`personaje` (`name`, `lastname`, `birthday`, `utiliza_magia`, `estatura`, `peso`, `equipo`, `magia_id`, `tipo_lucha_id`) VALUES (:name, :lastname, :date, :useMagic, :hight, :heigt, :haveTeam, :idMagic, :idLucha);');

                $query->bindParam(":name", $jsonData->name);
                $query->bindParam(":lastname", $jsonData->lastname);
                $query->bindParam(":date", $jsonData->birthday);
                $query->bindParam(":useMagic", $jsonData->utiliza_magia);
                $query->bindParam(":hight", $jsonData->estatura);
                $query->bindParam(":heigt", $jsonData->peso);
                $query->bindParam(":haveTeam", $jsonData->equipo);
                $query->bindParam(":idMagic", $jsonData->magia_id);
                $query->bindParam(":idLucha", $jsonData->tipo_lucha_id);
                $result = $query->execute();
                if ($result) {
                    $_POST["error"] = false;
                    $_POST["message"] = "Personaje registrado correctamente.";
                    $_POST["status"] = 200;
                } else {
                    $_POST["error"] = true;
                    $_POST["message"] = "Error al registrar";
                    $_POST["status"] = 400;
                }

                echo json_encode($_POST);
            } else {
                echo "ua existe";
            }
        }
        break;

    case 'PUT': //actualiza

        if ($_GET['accion'] == 'personaje') {
            $jsonData = json_decode(file_get_contents("php://input"));
            try {
                $conn = new PDO("mysql:host=localhost;dbname=kof", "root", "");
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
            $pstm = $conexion->prepare('SELECT id FROM kof.personaje WHERE id  = :num;');
            $pstm->bindParam(":num", $json->id);
            $pstm->execute();
            $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
            if ($rs != null) {
                if (!nombres($conn, $jsonData)) {

                    $query = $conn->prepare('UPDATE `kof`.`personaje` SET `name` = :name, `lastname` = :lastname, `birthday` = :date, `utiliza_magia` = :useMagic, `estatura` = :hight, `peso` =  :heigt, `equipo` = :haveTeam, `magia_id` = :idMagic, `tipo_lucha_id` = :idLucha WHERE (`id` = :id );');


                    $query->bindParam(":id", $jsonData->id);
                    $query->bindParam(":name", $jsonData->name);
                    $query->bindParam(":lastname", $jsonData->lastname);
                    $query->bindParam(":date", $jsonData->birthday);
                    $query->bindParam(":useMagic", $jsonData->utiliza_magia);
                    $query->bindParam(":hight", $jsonData->estatura);
                    $query->bindParam(":heigt", $jsonData->peso);
                    $query->bindParam(":haveTeam", $jsonData->equipo);
                    $query->bindParam(":idMagic", $jsonData->magia_id);
                    $query->bindParam(":idLucha", $jsonData->tipo_lucha_id);
                    $result = $query->execute();
                    if ($result) {
                        $_POST["error"] = false;
                        $_POST["message"] = "Personaje Actualizado  correctamente.";
                        $_POST["status"] = 200;
                    } else {
                        $_POST["error"] = true;
                        $_POST["message"] = "Error al actualizar";
                        $_POST["status"] = 400;
                    }

                    echo json_encode($_POST);
                } else {
                    echo "ya existe ";
                }
            } else {
                echo "la neta no funciona date de baja";
            }
        }

        break;


    case 'DELETE':

    default:
        echo "me kiero morir check";
        break;
}



function nombres($conn, $json)
{

    $pstm = $conn->prepare('SELECT * FROM kof.personaje WHERE `name`  = :name AND `lastname` = :lastname ');
    $pstm->bindParam(":name", $json->name);
    $pstm->bindParam(":lastname", $json->lastname);
    $pstm->execute();
    $rs = $pstm->fetchAll(PDO::FETCH_ASSOC);
    return $rs != null;
}
