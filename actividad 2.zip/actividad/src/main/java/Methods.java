public class Methods {
    public String addition (String nombre, double peso, double altura) {
        return "Hola " + nombre + " tu IMAC es " + altura/peso ;
    }
}
