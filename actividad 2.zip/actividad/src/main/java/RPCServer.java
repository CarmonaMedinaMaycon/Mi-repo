import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.webserver.WebServer;

import java.io.IOException;

public class RPCServer {
    public static void main(String[] args) throws XmlRpcException, IOException {
        System.out.println("inicializar server");
        PropertyHandlerMapping mapping = new PropertyHandlerMapping();
        mapping.addHandler( "Methods", Methods.class);
        mapping.addHandler( "Methods2", Methods2.class);
        mapping.addHandler( "Methods3", Methods3.class);
        mapping.addHandler( "Methods4", Methods4.class);
        WebServer server = new WebServer(1200);
        server.getXmlRpcServer().setHandlerMapping(mapping);
        server.start();
        System.out.println("waiting request");

    }
}
