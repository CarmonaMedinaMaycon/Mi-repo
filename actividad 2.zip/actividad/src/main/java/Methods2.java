public class Methods2 {
    public String addition (int n1, int n2, int n3, int n4) {
        int suma = n1+n2+n3+n4;
        return "Hola el producto es: " + (n1*n2*n3*n4) + " la suma es: " + suma  + " el promedio es: " + (suma/4) ;
    }
}
