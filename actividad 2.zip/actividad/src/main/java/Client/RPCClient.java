package Client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RPCClient {
    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL( "http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        Scanner leer = new Scanner(System.in);
        String nombre;
        double altura=0.0;
        double peso =0.0;
        System.out.println("escribe tu nombre");
         nombre = leer.next();
        System.out.println("escribe tu altura");
        altura = leer.nextDouble();
        System.out.println("escribe tu peso");
        peso = leer.nextDouble();


        Object[] data = {nombre, altura, peso};
        String response = (String) client.execute("Methods.addition", data);
        System.out.println("Result ->" + response);
    }
}
