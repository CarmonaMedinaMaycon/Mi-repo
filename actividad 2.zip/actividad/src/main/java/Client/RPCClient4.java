package Client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RPCClient4 {
    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL( "http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        Scanner leer = new Scanner(System.in);
        int d1,d2,d3,d4;

            System.out.println("escribe un numero");
            d1 = leer.nextInt();
        System.out.println("escribe un numero");
        d2 = leer.nextInt();

        System.out.println("escribe un numero");
        d3 = leer.nextInt();

        System.out.println("escribe un numero");
        d4 = leer.nextInt();






      Object[] data = {d1,d2,d3,d4};
        String response = (String) client.execute("Methods4.addition", data);
        System.out.println("Result ->" + response);

    }

}
