import java.util.Arrays;

public class Methods4 {
    public String addition ( int d1, int d2, int d3, int d4) {
        int n[] = {d1, d2, d3, d4};

        Arrays.sort(n);

        return "Hola" + Arrays.toString(n);

    }



}
