public class Methods3 {
    public String addition (int suma) {
        return ("Hola la suma del vector es: " + suma);
    }
}
