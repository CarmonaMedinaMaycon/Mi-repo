package mx.edu.utez.bottomappbar4a.model

data class Elemento (var imagen: Int,
var texto: String )