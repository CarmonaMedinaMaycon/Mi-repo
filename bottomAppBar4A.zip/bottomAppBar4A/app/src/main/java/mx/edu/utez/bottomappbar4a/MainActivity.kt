package mx.edu.utez.bottomappbar4a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import mx.edu.utez.bottomappbar4a.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomBar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menuAbrir -> {
                    Toast.makeText(this@MainActivity, "presionaste Play", Toast.LENGTH_SHORT).show()
                }
                R.id.menuSalir -> {
                    Toast.makeText(this@MainActivity, "presionaste Salir", Toast.LENGTH_SHORT)
                        .show()
                }
                R.id.menuConfig -> {
                    Toast.makeText(this@MainActivity, "presionaste Config", Toast.LENGTH_SHORT)
                        .show()
                }

            }

            true

        }
        binding.btnPochita.setOnClickListener{
            Toast.makeText(this@MainActivity, "presiona el boton pochis", Toast.LENGTH_SHORT).show()
        }

    }
}