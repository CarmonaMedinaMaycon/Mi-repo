package mx.edu.utez.bottomappbar4a.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import mx.edu.utez.bottomappbar4a.R
import mx.edu.utez.bottomappbar4a.model.Elemento

class CustomAdapter(val context: Context, val layout: Int, val datos:List<Elemento>):
    RecyclerView.Adapter<CustomAdapter.ElementoViewHolder>() {

    class ElementoViewHolder(inflater: LayoutInflater, parent: ViewGroup, layout: Int)
        : RecyclerView.ViewHolder(inflater.inflate(layout, parent, false)){
            //inica lo de la vista
            val imgImagen = itemView.findViewById<ImageView>(R.id.imgImagen)
        val txtTexto = itemView.findViewById<TextView>(R.id.txtTexto)
        fun bindDat(elemento: Elemento){
            imgImagen.setImageResource(elemento.imagen)
            txtTexto.text= elemento.texto
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ElementoViewHolder {
// crea una instancia del viewHolder y se lo asigna al RECYCLERVIEW( al iniciao, solo tiene elementos vacios
    // )
    }

    override fun onBindViewHolder(holder: ElementoViewHolder, position: Int) {
//llena las instancias del viwewHolder y ya se ven los datos
    }

    override fun getItemCount(): Int {
    //optiene la cantidad de elementos
        return datos.size
    }
}