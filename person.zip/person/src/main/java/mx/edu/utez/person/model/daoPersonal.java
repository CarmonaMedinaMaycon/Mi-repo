package mx.edu.utez.person.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class daoPersonal implements repositorio<beanPerson> {7
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;


    @Override
    public List<beanPerson> findAll() {
        return null;
    }

    @Override
    public beanPerson dindOne(long id) {
        return null;
    }

    @Override
    public boolean save(beanPerson object) {
        return false;
    }

    @Override
    public boolean update(beanPerson object) {
        return false;
    }

    @Override
    public boolean delete(long id) {
        return false;
    }
}
