package mx.edu.utez.person.model;

import java.util.List;

public interface repositorio<T> {
    List<T> findAll();
    T dindOne(long id);
    boolean save(T object);
    boolean update(T object);
    boolean delete(long id);






}
