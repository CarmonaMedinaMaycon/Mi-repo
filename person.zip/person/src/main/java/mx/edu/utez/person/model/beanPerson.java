package mx.edu.utez.person.model;

public class beanPerson {

    Long id;
    String namw;
    String surname;
    String lastname;
    String birthday;

    beanPosition position;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNamw() {
        return namw;
    }

    public void setNamw(String namw) {
        this.namw = namw;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public beanPosition getPosition() {
        return position;
    }

    public void setPosition(beanPosition position) {
        this.position = position;
    }
}
