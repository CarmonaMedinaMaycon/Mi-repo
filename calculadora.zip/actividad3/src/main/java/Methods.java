public class Methods {



    public double suma ( double n1 , double n2){
        return n1 + n2;
    }
    public double resta ( double n1 , double n2){
        return n1 - n2;
    }
    public double multiplicacion ( double n1 , double n2){
        return n1 * n2;
    }
    public double divicion ( double n1 , double n2){
        return n1 / n2;
    }
    public double exponente ( double n1 , double n2){
        return Math.pow(n1,n2);
    }
    public double raiz ( double n1 ){
        return Math.sqrt(n1);
    }

}
