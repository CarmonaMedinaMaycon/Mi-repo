package Client;

import java.sql.Date;

public class BeanCalcu {

long id;
String type;

double fris_Number;
    double second_Number;
    double resul;
    Date created_at = null;

    public BeanCalcu() {
    }

    public BeanCalcu(long id, String type, double fris_Number, double second_Number, double resul, Date created_at) {
        this.id = id;
        this.type = type ;
        this.fris_Number = fris_Number;
        this.second_Number = second_Number;
        this.resul = resul;
        this.created_at = created_at;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getFris_Number() {
        return fris_Number;
    }

    public void setFris_Number(double fris_Number) {
        this.fris_Number = fris_Number;
    }

    public double getSecond_Number() {
        return second_Number;
    }

    public void setSecond_Number(double second_Number) {
        this.second_Number = second_Number;
    }

    public double getResul() {
        return resul;
    }

    public void setResul(double resul) {
        this.resul = resul;
    }

    public Date getCreated_at() {

        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }
}
