package Client;

import utils.MySQLConnection;

import java.lang.reflect.Method;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DaoCalculadora {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;

    private final String SHOW = "SELECT * FROM operations;";
    private final String showw = "INSERT INTO operations (`type`, `firs_Number`, `second_Number`, `result`) VALUES (?, ?, ?, ?);";



    public List<BeanCalcu> show (){
        List<BeanCalcu> operationList = new LinkedList<>();
        BeanCalcu calcu = new BeanCalcu();

        try {
            conn = new MySQLConnection().getConnection();
            String query = SHOW;
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()){
                calcu = new BeanCalcu();
                calcu.setId(rs.getLong("id"));
                calcu.setType(rs.getString("type"));
                calcu.setFris_Number(rs.getDouble("firs_Number"));
                calcu.setSecond_Number(rs.getDouble("second_Number"));
                calcu.setResul(rs.getDouble("result"));
                calcu.setCreated_at(rs.getDate("Created_at"));
                operationList.add(calcu);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoCalculadora.class.getName()).log(Level.SEVERE, "Error en showAdmins -> ", e);
        }finally {
            closeConnections();
        }

        return operationList;
    }


    public boolean saveAOperacion(BeanCalcu operation){
        try{
            conn = new MySQLConnection().getConnection();
            pstm = conn.prepareStatement(showw);
            pstm.setString(1, operation.getType());
            pstm.setDouble(2, operation.getFris_Number());
            pstm.setDouble(3, operation.getSecond_Number());
            pstm.setDouble(4, operation.getResul());
            return pstm.executeUpdate() == 1;
        }catch (SQLException e){
            Logger.getLogger(DaoCalculadora.class.getName()).log(Level.SEVERE, "Error saveOperation", e);
        }finally {
            closeConnections();
        }
        return false;
    }


    public void closeConnections(){
        try {
            if (conn!=null){
                conn.close();
            }
            if (pstm!=null){
                pstm.close();
            }
            if (rs!=null){
                rs.close();
            }
        }catch (Exception e){
            System.out.println(e);
        }
    }
}
