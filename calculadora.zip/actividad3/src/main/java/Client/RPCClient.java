package Client;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RPCClient {
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        DaoCalculadora dao = new DaoCalculadora();
        BeanCalcu bean = new BeanCalcu();

        String menu = "", firstNumber = "", secundNumber = "", potencia="";
        do {
            System.out.println("Seleccione una opcion");
            System.out.println("1; suma");
            System.out.println("2; resta");
            System.out.println("3; multiplicacion");
            System.out.println("4; divicion");
            System.out.println("5; exponente");
            System.out.println("6; raiz");
            System.out.println("7; consultar historial");
            System.out.println("8; salir");
            menu = leer.next();
            bean.setType(menu);
            if (isNumber(menu)) {
                switch (Integer.parseInt(menu)) {
                    case 1:

                        System.out.println("suma");
                        do {
                            System.out.println("escribe el primer numero");
                            firstNumber = leer.next();
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));


                        } while (!isDouble(firstNumber));
                        do {
                            System.out.println("escribe el segundo numero");
                            secundNumber = leer.next();
                            bean.setSecond_Number(Double.parseDouble(secundNumber));

                            if (!isDouble(secundNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setSecond_Number(Double.parseDouble(secundNumber));

                        } while (!isDouble(firstNumber));

                        Object[] data = {Double.parseDouble(firstNumber),  Double.parseDouble(secundNumber) };
                        Double response = (Double) client.execute("Methods.suma", data);
                        System.out.println("Result ->" + response);
                        bean.setResul(response);

                        dao.saveAOperacion(bean);
                        //viene la ejecucion en el servidor...
                        break;
                    case 2:
                        System.out.println("resta");
                        do {
                            System.out.println("escribe el primer numero");
                            firstNumber = leer.next();
                            bean.setFris_Number(Double.parseDouble(firstNumber));
                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                        } while (!isDouble(firstNumber));
                        do {
                            System.out.println("escribe el segundo numero");
                            secundNumber = leer.next();
                            bean.setSecond_Number(Double.parseDouble(secundNumber));


                            if (!isDouble(secundNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setSecond_Number(Double.parseDouble(secundNumber));


                        } while (!isDouble(firstNumber));

                        Object[] data2 = {Double.parseDouble(firstNumber),  Double.parseDouble(secundNumber) };
                        Double response2 = (Double) client.execute("Methods.resta", data2);
                        System.out.println("Result ->" + response2);
                        bean.setResul(response2);

                        dao.saveAOperacion(bean);

                        break;
                    case 3:
                        System.out.println("multiplicacion");
                        do {
                            System.out.println("escribe el primer numero");
                            firstNumber = leer.next();
                            bean.setFris_Number(Double.parseDouble(firstNumber));
                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                        } while (!isDouble(firstNumber));
                        do {
                            System.out.println("escribe el segundo numero");
                            secundNumber = leer.next();
                            bean.setSecond_Number(Double.parseDouble(secundNumber));

                            if (!isDouble(secundNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setSecond_Number(Double.parseDouble(secundNumber));


                        } while (!isDouble(firstNumber));

                        Object[] data3 = {Double.parseDouble(firstNumber),  Double.parseDouble(secundNumber) };
                        Double response3 = (Double) client.execute("Methods.multiplicacion", data3);
                        System.out.println("Result ->" + response3);
                        bean.setResul(response3);

                        dao.saveAOperacion(bean);

                        break;
                    case 4:
                        System.out.println("divicion");
                        do {
                            System.out.println("escribe el primer numero");
                            firstNumber = leer.next();
                            bean.setFris_Number(Double.parseDouble(firstNumber));
                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                        } while (!isDouble(firstNumber));
                        do {
                            System.out.println("escribe el segundo numero");
                            secundNumber = leer.next();
                            bean.setSecond_Number(Double.parseDouble(secundNumber));

                            if (!isDouble(secundNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setSecond_Number(Double.parseDouble(secundNumber));


                        } while (!isDouble(firstNumber));

                        Object[] data4 = {Double.parseDouble(firstNumber),  Double.parseDouble(secundNumber) };
                        Double response4 = (Double) client.execute("Methods.divicion", data4);
                        System.out.println("Result ->" + response4);
                        bean.setResul(response4);

                        dao.saveAOperacion(bean);

                        break;
                    case 5:
                        System.out.println("exponente");
                        do {
                            System.out.println("escribe un numero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));
                            firstNumber = leer.next();
                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                        } while (!isDouble(firstNumber));
                        do {
                            System.out.println("escribe a que potencia lo quieres");
                             potencia = leer.next();
                            bean.setSecond_Number(Double.parseDouble(potencia));

                            if (!isDouble(potencia)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setSecond_Number(Double.parseDouble(potencia));


                        } while (!isDouble(firstNumber));



                        Object[] data5 = {  Double.parseDouble(firstNumber), Double.parseDouble(potencia) };
                        Double response5 = (Double) client.execute("Methods.exponente", data5);
                        System.out.println("Result ->" + response5);
                        bean.setResul(response5);

                        dao.saveAOperacion(bean);

                        break;
                    case 6:
                        System.out.println("raiz");
                        do {
                            System.out.println("escribe el primer numero");
                            firstNumber = leer.next();
                            bean.setFris_Number(Double.parseDouble(firstNumber));
                            if (!isDouble(firstNumber)) //mientras solo sea una linea el if no necesita llaves
                                System.out.println("escribe un numero entero");
                            bean.setFris_Number(Double.parseDouble(firstNumber));

                        } while (!isDouble(firstNumber));

                        Object[] data6 = {Double.parseDouble(firstNumber) };
                        Double response6 = (Double) client.execute("Methods.raiz", data6);
                        System.out.println("Result ->" + response6);

                        bean.setResul(response6);

                        dao.saveAOperacion(bean);

                        break;
                    case 7:
                        System.out.println("consultar historial");
                        System.out.println(dao.show().toString());

                        break;
                    case 8:
                        System.out.println("saliendo...");
                        break;
                    default:
                        System.out.println("tas mal mi loco");
                        break;
                }

            } else {

                System.out.println("la opcion es incorrecta");
            }
        } while (!menu.equals("8"));





    }

    public static boolean isNumber(String number) {
        try {
            Integer.parseInt(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isDouble(String number) {
        try {
            Double.parseDouble(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
