export type Entity<T extends number | string> = {
  id: T;
};
