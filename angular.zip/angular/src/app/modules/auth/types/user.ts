export type UserLogin = {
  email: string;
  password: string;
};
