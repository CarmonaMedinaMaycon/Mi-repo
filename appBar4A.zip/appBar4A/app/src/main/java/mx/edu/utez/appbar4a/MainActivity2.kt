package mx.edu.utez.appbar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.appbar4a.databinding.ActivityMain2Binding
import mx.edu.utez.appbar4a.databinding.ActivityMainBinding

class MainActivity2 : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        var memoria = intent.getStringExtra("memoria")

        binding.btnPantalla2.setOnClickListener {
            val intent = Intent(this@MainActivity2,MainActivity3::class.java)

            val seleccion = binding.rgProcesador.checkedRadioButtonId
            var procesador = ""
            when(seleccion){
                R.id.rdbI5 -> { procesador = "i5 de 8taba"}
                R.id.rdbi7 -> { procesador = "i7 de 8taba"}
                R.id.rdbrazen7 -> { procesador = "razen 7"}
                else -> {procesador = "sin seleccion"}
            }
            intent.putExtra("memoria", memoria)
            intent.putExtra("procesador", procesador)
            startActivity(intent)
        }
    }
}