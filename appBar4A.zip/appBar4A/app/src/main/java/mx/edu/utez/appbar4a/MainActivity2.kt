package mx.edu.utez.appbar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.appbar4a.databinding.ActivityMain2Binding
import mx.edu.utez.appbar4a.databinding.ActivityMainBinding

class MainActivity2 : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPantalla2.setOnClickListener {
            startActivity(Intent(this@MainActivity2, MainActivity3::class.java))
        }
    }
}