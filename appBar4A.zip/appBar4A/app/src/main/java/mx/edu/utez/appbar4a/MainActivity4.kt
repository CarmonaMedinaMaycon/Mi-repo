package mx.edu.utez.appbar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.utez.appbar4a.databinding.ActivityMain4Binding
import mx.edu.utez.appbar4a.databinding.ActivityMainBinding

class MainActivity4 : AppCompatActivity() {
    lateinit var binding: ActivityMain4Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain4Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPantalla4.setOnClickListener {
            val intent = (Intent(this@MainActivity4, MainActivity::class.java))
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK //es para vaciar la pila
            startActivity(intent)
        }
    }
}


