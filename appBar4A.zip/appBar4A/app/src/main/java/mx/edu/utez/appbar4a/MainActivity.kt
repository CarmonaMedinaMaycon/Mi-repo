package mx.edu.utez.appbar4a

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import mx.edu.utez.appbar4a.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate((layoutInflater))
        setContentView(binding.root)



        binding.btnPantalla1.setOnClickListener {
            val seleccion = binding.rgMemoria.checkedRadioButtonId
            var memoria = ""
            when(seleccion){
                R.id.rdb16 -> { memoria = "16GB"}
                R.id.btn8 -> { memoria = "8GB"}
                R.id.rtn4 -> { memoria = "4GB"}
                else -> {memoria = "sin seleccion"}
            }

            startActivity(Intent(this@MainActivity, MainActivity2::class.java))
            intent.putExtra("memoria", memoria)
            startActivity(intent)

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // inflate - leer un archivo XML (diseno) y crea una instancia de el
        // con sus controles(inflar)
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when
        return super.onOptionsItemSelected(item)
    }
}