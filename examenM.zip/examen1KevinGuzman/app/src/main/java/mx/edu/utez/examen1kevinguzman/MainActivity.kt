package mx.edu.utez.examen1kevinguzman

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import mx.edu.utez.examen1kevinguzman.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val formatDecimalFormat = DecimalFormat("#.00")

        val EditSpinner : Spinner = binding.spinner2
        ArrayAdapter.createFromResource(
            this,
            R.array.spinner2,
            android.R.layout.simple_spinner_item
        ).also{
                adapter->adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            EditSpinner.adapter = adapter
        }

        val btnResultado = binding.button
        btnResultado.setOnClickListener {
            val operacionString = EditSpinner.selectedItem.toString()
            val data1 = binding.dato1.text.toString()
            val data2 = binding.dato2.text.toString()
            var resultado = binding.output

            if (data1.isNotEmpty() && data2.isNotEmpty()){
                when(operacionString){
                    "sumar" -> {
                        try {
                            val parsedDouble1 = data1.toDouble()
                            val parsedDouble2 = data2.toDouble()
                            var total = parsedDouble1 + parsedDouble2
                            total = formatDecimalFormat.format(total).toDouble()
                            resultado.text = "El resultado es: $total"
                        } catch (nfe: NumberFormatException) {
                            resultado.text="Numero invalido"
                        }

                    }
                    "restar" -> {
                        try {
                            val parsedDouble1 = data1.toDouble()
                            val parsedDouble2 = data2.toDouble()
                            var total = parsedDouble1 - parsedDouble2
                            total = formatDecimalFormat.format(total).toDouble()
                            resultado.text = "El resultado es: $total"
                        } catch (nfe: NumberFormatException) {
                            resultado.text="Numero invalido"
                        }
                    }
                    "multiplicar" -> {
                        try {
                            val parsedDouble1 = data1.toDouble()
                            val parsedDouble2 = data2.toDouble()
                            var total = parsedDouble1 * parsedDouble2
                            total = formatDecimalFormat.format(total).toDouble()
                            resultado.text = "El resultado es: $total"
                        } catch (nfe: NumberFormatException) {
                            resultado.text="Numero invalido"
                        }

                    }
                    "dividir" ->{
                        try {
                            val parsedDouble1 = data1.toDouble()
                            val parsedDouble2 = data2.toDouble()
                            var total = parsedDouble1 / parsedDouble2
                            total = formatDecimalFormat.format(total).toDouble()
                            resultado.text = "El resultado es: $total"
                        } catch (nfe: NumberFormatException) {
                            resultado.text="Numero invalido"
                        }

                    }
                    "brindar" ->{
                        resultado.text="El nombre es: $data1 y el apellido es: $data2"
                    }
                }
            }else{
                Toast.makeText(this@MainActivity, "Llenar primero los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}